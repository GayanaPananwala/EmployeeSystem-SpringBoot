package com.example.employeespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
